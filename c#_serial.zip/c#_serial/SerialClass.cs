﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO.Ports;

namespace CarParkingApp
{
    class SerialClass
    {
        public SerialPort serialPort;
        string comPort;

        int recvSize = 0;  
        byte[] buff = new byte[1024];
        public int recvTotalSize = 0;
        public byte[] totalBuff = new byte[1024];
        

        public SerialClass(string comPort)
        {
            this.comPort = comPort;
        }

        public SerialPort SerialOpen()
        {
            SerialPort sPort = null;

            try
            {
                if (serialPort == null)
                {
                    serialPort = new SerialPort();
                    serialPort.DataReceived += new SerialDataReceivedEventHandler(SerialDataReceived);
                    serialPort.ErrorReceived += new SerialErrorReceivedEventHandler(SerialErrorReceived);

                    serialPort.PortName = comPort;
                    //sPort2.PortName = "/dev/ttyUSB0";
                    serialPort.BaudRate = 115200;
                    serialPort.DataBits = (int)8;
                    serialPort.Parity = Parity.None;
                    serialPort.StopBits = StopBits.One;
                    serialPort.ReadTimeout = (int)500;
                    serialPort.WriteTimeout = (int)500;
                    serialPort.Open();

                    if (serialPort.IsOpen)
                    {
                        sPort = serialPort;

                        //serialPort2Connected = true;
                        //SerialThreadInit2();
                    }
                }
                else
                {

                }
            }
            catch (System.Exception ex)
            {
                serialPort.Close();
                serialPort.Dispose();
                serialPort = null;
            }

            return sPort;
        }

        void SerialDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            recvSize = serialPort.BytesToRead;
            //Console.WriteLine("[{0}]recvSize = {1}", serialPort.PortName , recvSize);

            if (recvSize != 0)
            {

                if (serialPort != null)
                {
                    serialPort.Read(buff, 0, recvSize);
                }

                for (int i = 0; i < recvSize; i++)
                {
                    if (i + recvTotalSize > 1023) break;
                    else if (i + recvTotalSize < 0) break;

                    totalBuff[i + recvTotalSize] = buff[i];
                }
                recvTotalSize += recvSize;

                //Console.WriteLine("recvTotalSize = " + recvTotalSize);
            }

        }

        void SerialErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            SerialError err = e.EventType;
            string strErr = "";
            switch (err)
            {
                case SerialError.Frame:
                    strErr = "HardWare Framing Error";
                    break;
                case SerialError.Overrun:
                    strErr = "Charaters Buffer Over Run";
                    break;
                case SerialError.RXOver:
                    strErr = "Input Buffer OverFlow";
                    break;
                case SerialError.RXParity:
                    strErr = "Founded Parity Error";
                    break;
                case SerialError.TXFull:
                    strErr = "Write Buffer was Fulled";
                    break;
                default:
                    break;
            }

            Console.WriteLine(strErr);
        }

        public void SerialWrite(byte[] sendData, int sendSize)
        {
            if (serialPort != null)
            {
                serialPort.Write(sendData, 0, sendSize);
            }
        }
    }
}
